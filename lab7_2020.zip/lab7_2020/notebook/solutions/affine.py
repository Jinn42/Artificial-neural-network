def affine(x, w, b):
    return w * x + b
