Title: Lab 3: Scikit-learn for Regression
Category: labs
Slug: lab-3
Author: Pavlos Protopapas
Date: 2018-09-20
Tags: Scikit-learn, Linear Regression, k-Nearest Neighbors (kNN) Regression

## Jupyter Notebooks

- [Lab 3: Scikit-learn for Regression - Student Version]({filename}notebook/lab3_SLR_KNN.ipynb)
- [Lab 3: Scikit-learn for Regression - Solutions]({filename}notebook/solutions/lab3_solutions.ipynb)